const towns = [
    "Montpellier",
    "Lyon",
    "Paris",
    "Marseille",
    "Clermont-Ferrand",
    "Lille",
    "Nantes",
    "New york",
    "Los angeles",
    "Miami",
    "Barcelone",
    "Madrid",
    "Porto",
    "Lisbonne",
    "Montluçon"
];
